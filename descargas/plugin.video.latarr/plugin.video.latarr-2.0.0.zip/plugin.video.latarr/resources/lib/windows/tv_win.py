"""
tv_win.py — Televisión en Vivo para Latarr.

Navegación fluida por países y canales con diseño Apple TV (tarjetas y logos en alta definición).
Reproducción directa en el reproductor nativo de Kodi sin plugins PVR.
Soporte de señales alternativas automáticas ante caídas.
Incluye integración con Zapping TV (23 países en vivo).
"""

import os
import json
import xbmc
import xbmcgui
import xbmcaddon

from .. import api

addon = xbmcaddon.Addon()


class LatarrTVDialog(xbmcgui.WindowXMLDialog):
    """Ventana de Televisión en Vivo por Países y Categorías (con soporte Zapping TV)."""

    def __init__(self, *args, **kwargs):
        self.addon_path = kwargs.pop('addon_path', '')
        self.initial_country = kwargs.pop('initial_country', None)
        self.initial_category = kwargs.pop('initial_category', 'Todas')
        self.initial_pos = kwargs.pop('initial_pos', 0)
        self.initial_is_zapping = kwargs.pop('is_zapping', False)
        super().__init__(*args, **kwargs)

        self.initialized = False
        self.played = False
        self.resume_data = None

        self.view_mode = 'countries'  # 'countries' o 'channels'
        self.is_zapping = self.initial_is_zapping
        self.countries = []
        self.normal_countries = []
        self.zapping_countries = []
        self.raw_channels = []
        self.channels = []
        self.categories = ['Todas']
        self.current_country = self.initial_country
        self.current_country_name = ''
        self.current_category = self.initial_category
        self._last_country_pos = 0

    def onInit(self):
        if self.initialized:
            return
        self.initialized = True

        self.normal_countries = api.get_tv_countries()
        self.countries = self.normal_countries

        if self.is_zapping and not self.zapping_countries:
            self.zapping_countries = api.get_zapping_countries()
            self.countries = self.zapping_countries

        if self.initial_country:
            normal_codes = [c.get('codigo') for c in self.normal_countries]
            if self.is_zapping or (self.initial_country not in normal_codes):
                self.is_zapping = True
                if not self.zapping_countries:
                    self.zapping_countries = api.get_zapping_countries()
                self.countries = self.zapping_countries
            self._show_channels(self.initial_country, category=self.initial_category, select_pos=self.initial_pos)
        else:
            self._show_countries(select_pos=self.initial_pos)

    # ------------------------------------------------------------------ Vistas
    def _show_countries(self, select_pos=0):
        """Muestra la cuadrícula de países disponibles."""
        self.view_mode = 'countries'
        ctrl = self.getControl(8100)
        ctrl.reset()

        flags_dir = os.path.join(self.addon_path, 'resources', 'skins', 'Default', 'media', 'flags')
        items = []

        if self.is_zapping:
            self.setProperty('tv_title', '[B]ZAPPING[/B] [COLOR FF8E95A5]TV[/COLOR]')
            self.setProperty('btn_back_label', '← Volver a TV')
            self.setProperty('filter_country', 'Países Zapping')
            self.setProperty('filter_category', 'Todas')

            if not self.zapping_countries:
                self.zapping_countries = api.get_zapping_countries()
            self.countries = self.zapping_countries

            if not self.countries:
                self.setProperty('selected_name', 'Sin países Zapping disponibles')
                self.setProperty('selected_extra', 'Verifica tu conexión')
                self.setProperty('total_count_label', '0 países')
                self.setFocusId(8005)
                return

            self.setProperty('total_count_label', f'{len(self.countries)} países Zapping')

            for c in self.countries:
                code = c.get('codigo', '')
                name = c.get('nombre', code)
                total = c.get('total', 0)

                flag_file = os.path.join(flags_dir, f'flag_{code}.png')
                thumb = flag_file if os.path.exists(flag_file) else 'button_normal.png'

                li = xbmcgui.ListItem(label=name)
                li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
                li.setProperty('item_type', 'country')
                li.setProperty('country_code', code)
                li.setProperty('country_name', name)
                li.setProperty('subtitle', f'{total} canales')
                li.setProperty('total', str(total))
                items.append(li)

        else:
            self.setProperty('tv_title', '[B]TV[/B] [COLOR FF8E95A5]EN VIVO[/COLOR]')
            self.setProperty('btn_back_label', 'Volver a Inicio')
            self.setProperty('filter_country', 'Países')
            self.setProperty('filter_category', 'Todas')

            if not self.normal_countries:
                self.normal_countries = api.get_tv_countries()
            self.countries = self.normal_countries

            # ── 1. Tarjeta ZAPPING TV al inicio ─────────────────────────────
            zap_icon = os.path.join(flags_dir, 'flag_ZAP.png')
            if not os.path.exists(zap_icon):
                zap_icon = os.path.join(flags_dir, 'flag_INT.png')
            if not os.path.exists(zap_icon):
                zap_icon = 'button_normal.png'

            li_zap = xbmcgui.ListItem(label='📡 ZAPPING TV')
            li_zap.setArt({'thumb': zap_icon, 'icon': zap_icon, 'poster': zap_icon})
            li_zap.setProperty('item_type', 'toggle_zapping')
            li_zap.setProperty('country_code', 'ZAP')
            li_zap.setProperty('country_name', 'Zapping TV')
            li_zap.setProperty('subtitle', '[COLOR FFFFAA00]⚡ 23 Países · Canales en Vivo[/COLOR]')
            li_zap.setProperty('total', 'ZAP')
            items.append(li_zap)

            # ── 2. Países normales ──────────────────────────────────────────
            for c in self.countries:
                code = c.get('codigo', '')
                name = c.get('nombre', code)
                total = c.get('total', 0)

                flag_file = os.path.join(flags_dir, f'flag_{code}.png')
                thumb = flag_file if os.path.exists(flag_file) else 'button_normal.png'

                li = xbmcgui.ListItem(label=name)
                li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
                li.setProperty('item_type', 'country')
                li.setProperty('country_code', code)
                li.setProperty('country_name', name)
                li.setProperty('subtitle', f'{total} canales')
                li.setProperty('total', str(total))
                items.append(li)

            self.setProperty('total_count_label', f'{len(self.countries)} países disponibles')

        ctrl.addItems(items)
        self.setFocusId(8100)

        target_pos = select_pos if select_pos > 0 else self._last_country_pos
        if 0 <= target_pos < len(items):
            try:
                ctrl.selectItem(target_pos)
            except Exception:
                pass

        self._update_selected_info()

    def _show_channels(self, country_code, category='Todas', select_pos=0):
        """Carga y muestra la cuadrícula de canales del país indicado."""
        self.view_mode = 'channels'
        self.current_country = country_code

        # Determinar nombre del país
        current_list = self.zapping_countries if self.is_zapping else self.normal_countries
        c_name = country_code
        for c in current_list:
            if c.get('codigo') == country_code:
                c_name = c.get('nombre', country_code)
                break
        self.current_country_name = c_name

        self.setProperty('btn_back_label', '← Países')
        prefix = 'Zapping: ' if self.is_zapping else 'País: '
        self.setProperty('filter_country', f'{prefix}{c_name}')

        ctrl = self.getControl(8100)
        ctrl.reset()

        if self.is_zapping:
            data = api.get_zapping_channels(country_code)
        else:
            data = api.get_tv_channels(country_code)

        self.raw_channels = data.get('canales', [])
        cats = data.get('categorias', [])
        self.categories = ['Todas'] + [cat for cat in cats if cat]
        self.current_category = category if category in self.categories else 'Todas'

        self.setProperty('filter_category', f'Categoría: {self.current_category}')

        if self.current_category != 'Todas':
            self.channels = [ch for ch in self.raw_channels if ch.get('categoria') == self.current_category]
        else:
            self.channels = list(self.raw_channels)

        tag = f"Zapping {c_name}" if self.is_zapping else c_name
        self.setProperty('total_count_label', f'{len(self.channels)} canales ({tag})')

        if not self.channels:
            self.setProperty('selected_name', 'Sin canales en esta categoría')
            self.setProperty('selected_extra', '')
            self.setFocusId(8002)
            return

        items = []
        for ch in self.channels:
            name = ch.get('nombre', 'Canal')
            logo = ch.get('logo', '')
            cat = ch.get('categoria', '')

            li = xbmcgui.ListItem(label=name)
            li.setArt({'thumb': logo, 'icon': logo, 'poster': logo})
            li.setProperty('stream_url', ch.get('url', ''))
            li.setProperty('alternativas', json.dumps(ch.get('alternativas', [])))
            li.setProperty('channel_name', name)
            li.setProperty('categoria', cat)
            li.setProperty('subtitle', cat)
            items.append(li)

        ctrl.addItems(items)
        self.setFocusId(8100)

        if 0 <= select_pos < len(items):
            try:
                ctrl.selectItem(select_pos)
            except Exception:
                pass

        self._update_selected_info()

    # ------------------------------------------------------------------ Info
    def _update_selected_info(self):
        try:
            ctrl = self.getControl(8100)
            item = ctrl.getSelectedItem()
            if not item:
                return
            if self.view_mode == 'countries':
                self.setProperty('selected_name', item.getLabel())
                self.setProperty('selected_extra', item.getProperty('subtitle') or '')
            else:
                self.setProperty('selected_name', item.getLabel())
                self.setProperty('selected_extra', item.getProperty('categoria') or '')
        except Exception:
            pass

    # ------------------------------------------------------------------ Navegación
    def onAction(self, action):
        action_id = action.getId()
        if action_id in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            if self.view_mode == 'channels':
                self._show_countries(select_pos=self._last_country_pos)
                return
            elif self.is_zapping:
                self.is_zapping = False
                self.current_country = None
                self.current_category = 'Todas'
                self._last_country_pos = 0
                self._show_countries(select_pos=0)
                return
            else:
                self.close()
                return

        try:
            super().onAction(action)
        except Exception:
            pass

        if self.getFocusId() == 8100:
            self._update_selected_info()

    def onClick(self, control_id):
        if control_id == 8100:
            ctrl = self.getControl(8100)
            item = ctrl.getSelectedItem()
            if not item:
                return

            item_type = item.getProperty('item_type')
            if item_type == 'toggle_zapping':
                self.is_zapping = True
                self.current_country = None
                self.current_category = 'Todas'
                self._last_country_pos = 0
                self._show_countries(select_pos=0)
                return

            if self.view_mode == 'countries':
                self._last_country_pos = ctrl.getSelectedPosition()
                code = item.getProperty('country_code')
                self._show_channels(code, category='Todas')
            else:
                pos = ctrl.getSelectedPosition()
                self._on_channel_selected(item, pos)

        elif control_id == 8005:  # Botón Volver
            if self.view_mode == 'channels':
                self._show_countries(select_pos=self._last_country_pos)
            elif self.is_zapping:
                self.is_zapping = False
                self.current_country = None
                self.current_category = 'Todas'
                self._last_country_pos = 0
                self._show_countries(select_pos=0)
            else:
                self.close()

        elif control_id == 8001:  # Selector de País
            self._select_country_dialog()

        elif control_id == 8002:  # Selector de Categoría
            if self.view_mode == 'channels':
                self._select_category_dialog()
            else:
                xbmcgui.Dialog().notification('Latarr TV', 'Selecciona primero un país', xbmcgui.NOTIFICATION_INFO, 2000)

    # ------------------------------------------------------------------ Diálogos Filtros
    def _select_country_dialog(self):
        active_list = self.zapping_countries if self.is_zapping else self.normal_countries
        if not active_list:
            return
        country_names = [f"{c.get('nombre', '')} ({c.get('total', 0)} canales)" for c in active_list]
        title = 'Seleccionar País Zapping' if self.is_zapping else 'Seleccionar País'
        idx = xbmcgui.Dialog().select(title, country_names)
        if idx >= 0:
            self._last_country_pos = idx
            code = active_list[idx].get('codigo')
            if code:
                self._show_channels(code, category='Todas')

    def _select_category_dialog(self):
        if not self.categories:
            return
        idx = xbmcgui.Dialog().select('Filtrar Categoría', self.categories)
        if idx >= 0:
            cat = self.categories[idx]
            self._show_channels(self.current_country, category=cat)

    # ------------------------------------------------------------------ Reproducción
    def _on_channel_selected(self, item, pos):
        url = item.getProperty('stream_url')
        if not url:
            xbmcgui.Dialog().notification('Latarr TV', 'Enlace no disponible', xbmcgui.NOTIFICATION_WARNING, 2000)
            return

        alts_raw = item.getProperty('alternativas')
        alternativas = []
        if alts_raw:
            try:
                alternativas = json.loads(alts_raw)
            except Exception:
                alternativas = []

        nombre = item.getProperty('channel_name') or item.getLabel()
        logo = item.getArt('thumb') or ''

        self._play_stream(url, alternativas, nombre, logo, pos)

    def _play_stream(self, url, alternativas, nombre, logo, pos):
        li = xbmcgui.ListItem(label=nombre)
        li.setArt({'thumb': logo, 'icon': logo, 'poster': logo})
        li.setInfo('video', {
            'title': nombre,
            'mediatype': 'video',
        })
        li.setProperty('IsPlayable', 'true')

        player = xbmc.Player()
        player.play(url, li)

        # Esperar brevemente para confirmar que el reproductor arrancó
        monitor = xbmc.Monitor()
        started = False
        for _ in range(14):  # ~4.2 segundos
            if monitor.abortRequested():
                return
            if player.isPlayingVideo() or player.isPlaying():
                started = True
                break
            monitor.waitForAbort(0.3)

        # Si falló la señal principal, intentar alternativas
        if not started and alternativas:
            for alt_url in alternativas:
                if monitor.abortRequested():
                    return
                xbmc.log(f"[LATARR-TV] Señal principal caída ({url}), probando alternativa: {alt_url}", xbmc.LOGWARNING)
                xbmcgui.Dialog().notification('Latarr TV', f'Probando señal alternativa de {nombre}...', xbmcgui.NOTIFICATION_INFO, 2000)
                player.play(alt_url, li)
                for _ in range(12):
                    if monitor.abortRequested():
                        return
                    if player.isPlayingVideo() or player.isPlaying():
                        started = True
                        break
                    monitor.waitForAbort(0.3)
                if started:
                    break

        if started:
            self.played = True
            section = 'zapping' if self.is_zapping else 'tv'
            self.resume_data = {
                'section': section,
                'country': self.current_country,
                'category': self.current_category,
                'pos': pos,
            }
            self.close()
        else:
            xbmcgui.Dialog().notification('Latarr TV', f'No se pudo conectar a {nombre}', xbmcgui.NOTIFICATION_WARNING, 3000)
