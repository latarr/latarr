# -*- coding: utf-8 -*-
# LATARR TV PRO — plugin.video.latarr.tv
# Addon independiente de televisión en vivo con skin premium propia.
# Autor: Oscar | Latarr

import sys
import os
import json
import base64
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
from urllib.parse import parse_qsl
try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError
except ImportError:
    from urllib2 import urlopen, Request, URLError

ADDON      = xbmcaddon.Addon()
ADDON_PATH = ADDON.getAddonInfo('path')

# ─────────────────────────────────────────────────────────────────
#  DATOS Y CONFIGURACIÓN
# ─────────────────────────────────────────────────────────────────

NOMBRES_PAISES = {
    'AR': 'Argentina', 'BO': 'Bolivia', 'BR': 'Brasil', 'CL': 'Chile',
    'CO': 'Colombia', 'CR': 'Costa Rica', 'CU': 'Cuba', 'DO': 'Rep. Dominicana',
    'EC': 'Ecuador', 'ES': 'España', 'GT': 'Guatemala', 'HN': 'Honduras',
    'INT': 'Internacional', 'MX': 'México', 'NI': 'Nicaragua', 'PA': 'Panamá',
    'PE': 'Perú', 'PR': 'Puerto Rico', 'PY': 'Paraguay', 'SV': 'El Salvador',
    'US': 'USA Latino', 'UY': 'Uruguay', 'VE': 'Venezuela',
}

CATEGORIAS_DEPORTES  = ('deportes', 'sports', 'deporte')
CATEGORIAS_CINE      = ('cine y series', 'peliculas', 'series', 'movies', 'cine')
CATEGORIAS_INFANTIL  = ('infantil', 'kids', 'ninos', 'niños')
CATEGORIAS_MUSICA    = ('musica', 'music', 'música')

AGENDA_URL   = 'https://api.wqxag.com/diaries.json'
IMG_BASE_URL = 'https://img.wqxag.com'

# Emojis por tipo de deporte (palabra clave en el título del evento)
SPORT_EMOJIS = {
    'tenis': '🎾', 'tennis': '🎾',
    'nba': '🏀', 'basket': '🏀',
    'nfl': '🏈', 'rugby': '🏉',
    'formula': '🏎️', 'f1': '🏎️',
    'golf': '⛳',
    'boxeo': '🥊', 'box': '🥊', 'mma': '🥊',
    'beisbol': '⚾', 'baseball': '⚾',
    'voleibol': '🏐', 'volleyball': '🏐',
    'hockey': '🏒',
}


def _emoji_evento(titulo):
    t = titulo.lower()
    for clave, emoji in SPORT_EMOJIS.items():
        if clave in t:
            return emoji
    return '⚽'


def cargar_agenda():
    """Descarga la agenda del día desde la API de Fútbol Libre y retorna lista de eventos."""
    try:
        req = Request(
            AGENDA_URL,
            headers={
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64)',
                'Accept': 'application/json',
                'Referer': 'https://futbollibretvgol.org/'
            }
        )
        resp = urlopen(req, timeout=12)
        raw  = json.loads(resp.read().decode('utf-8'))
        eventos = raw if isinstance(raw, list) else raw.get('data', [])
        return eventos
    except Exception as e:
        xbmc.log(f'[LATARR TV PRO] Error agenda: {e}', xbmc.LOGERROR)
        return []


def _decodificar_embed(embed_iframe):
    """Extrae la URL de tvf90 del embed codificado en Base64."""
    try:
        if '?r=' in embed_iframe:
            b64 = embed_iframe.split('?r=')[-1].strip()
            decoded = base64.b64decode(b64 + '==').decode('utf-8')
            return decoded
        return embed_iframe
    except Exception:
        return embed_iframe


def _resolver_stream(url_tvf90):
    """
    Dada la URL de tvf90 (ej: https://tvf90.com/1.php?stream=espn2),
    navega al iframe /5.php y extrae el .m3u8 real para Kodi.
    """
    import re as _re
    from urllib.parse import urljoin as _urljoin

    PAT_IFRAME = r'<iframe[^>]+src=["\']?(/[^"\'>\s]+)'
    PAT_M3U8   = r'https?://[^\s"\'>]+\.m3u8[^\s"\'>]*'

    _h1 = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Referer':    'https://futbollibretvgol.org/'
    }
    try:
        req1  = Request(url_tvf90, headers=_h1)
        html1 = urlopen(req1, timeout=12).read().decode('utf-8', errors='ignore')

        iframes = _re.findall(PAT_IFRAME, html1)
        if not iframes:
            m3u8 = _re.findall(PAT_M3U8, html1)
            return m3u8[0] if m3u8 else None

        url_iframe = _urljoin(url_tvf90, iframes[0])
        _h2 = dict(_h1)
        _h2['Referer'] = url_tvf90
        req2  = Request(url_iframe, headers=_h2)
        html2 = urlopen(req2, timeout=12).read().decode('utf-8', errors='ignore')

        m3u8 = _re.findall(PAT_M3U8, html2)
        return m3u8[0] if m3u8 else None

    except Exception as e:
        try:
            xbmc.log('[LATARR TV PRO] Error resolver stream: ' + str(e), xbmc.LOGERROR)
        except Exception:
            pass
        return None


def _hora_local(hora_utc):
    """Ajusta la hora UTC a hora local de Chile (UTC-3)."""
    try:
        h, m, _ = hora_utc.split(':')
        total = int(h) * 60 + int(m) - 180  # -3 hrs
        total = total % (24 * 60)
        return f"{total // 60:02d}:{total % 60:02d}"
    except Exception:
        return hora_utc[:5] if hora_utc else '??:??'


def data_path(filename):
    return os.path.join(ADDON_PATH, 'resources', 'data', filename)


def cargar_paises():
    """Retorna lista de dicts con 'codigo', 'nombre', 'total'."""
    try:
        with open(data_path('paises.json'), 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data.get('paises', [])
        return data
    except Exception as e:
        xbmc.log(f'[LATARR TV PRO] Error paises.json: {e}', xbmc.LOGERROR)
        return []


def cargar_canales(codigo):
    """Retorna lista de dicts de canales para el país dado."""
    path = data_path(f'tv_{codigo}.json')
    if not os.path.exists(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if isinstance(data, dict):
            return data.get('canales', [])
        return data
    except Exception as e:
        xbmc.log(f'[LATARR TV PRO] Error tv_{codigo}.json: {e}', xbmc.LOGERROR)
        return []


def cargar_todos():
    todos = []
    for p in cargar_paises():
        codigo = p.get('codigo', '')
        if codigo:
            todos.extend(cargar_canales(codigo))
    return todos


def filtrar_por_categoria(todos, categorias_tuple):
    return [c for c in todos if c.get('categoria', '').lower().strip() in categorias_tuple]


def check_disclaimer():
    """Muestra el descargo de responsabilidad legal al usuario CADA VEZ que abre el addon."""
    dialog = xbmcgui.Dialog()
    accepted = dialog.yesno(
        "Aviso Legal - Latarr TV PRO",
        "Este complemento recopila y organiza enlaces IPTV públicos de libre acceso en GitHub.\n\n"
        "Latarr TV PRO no aloja, retransmite ni controla ningún contenido audiovisual.\n"
        "El acceso y uso de las señales es bajo la exclusiva responsabilidad del usuario.\n\n"
        "¿Aceptas estos términos y deseas continuar?",
        yeslabel="Aceptar",
        nolabel="Cancelar"
    )
    return bool(accepted)


# ─────────────────────────────────────────────────────────────────
#  VENTANA PRINCIPAL — WindowXMLDialog con skin propia
# ─────────────────────────────────────────────────────────────────

class LatarrTVProWindow(xbmcgui.WindowXMLDialog):

    MODE_GRID   = 'grid'
    MODE_PAISES = 'paises'
    MODE_AGENDA = 'agenda'

    def __init__(self, *args, **kwargs):
        self.resume_data = kwargs.pop('resume_data', None)
        super().__init__(*args, **kwargs)
        self.initialized          = False
        self.played               = False
        self.current_tab          = 107
        self.view_mode            = self.MODE_AGENDA
        self.channels             = []
        self.paises_list          = []
        self._agenda              = []
        self._last_pos            = 0
        self._desde_internacional = False
        self._current_country_code = None
        self._current_country_name = None

    def onInit(self):
        if self.initialized:
            return
        self.initialized = True

        if self.resume_data:
            tab = self.resume_data.get('tab', 107)
            mode = self.resume_data.get('mode', self.MODE_AGENDA)
            pos = self.resume_data.get('pos', 0)
            desde_int = self.resume_data.get('desde_int', False)
            c_code = self.resume_data.get('country_code')
            c_name = self.resume_data.get('country_name')

            self.current_tab = tab
            if desde_int and c_code:
                self._desde_internacional = True
                self._current_country_code = c_code
                self._current_country_name = c_name
                canales = cargar_canales(c_code)
                canales.sort(key=lambda x: x.get('nombre', '').lower())
                self._mostrar_canales(canales, c_name or c_code, select_pos=pos)
            elif mode == self.MODE_AGENDA:
                self._mostrar_agenda(select_pos=pos)
            elif mode == self.MODE_PAISES:
                self._mostrar_paises(select_pos=pos)
            else:
                self._cargar_tab(tab, select_pos=pos)
        else:
            self._mostrar_agenda()

    # ── Cargar pestaña ──────────────────────────────────────────
    def _cargar_tab(self, tab_id, select_pos=0):
        self.current_tab = tab_id
        self._last_pos   = select_pos
        self._desde_internacional = False
        self._current_country_code = None
        self._current_country_name = None

        if tab_id == 107:    # Eventos del Día
            self._mostrar_agenda(select_pos=select_pos)

        elif tab_id == 101:    # Deportes
            todos = cargar_todos()
            canales = filtrar_por_categoria(todos, CATEGORIAS_DEPORTES)
            canales.sort(key=lambda x: x.get('nombre', '').lower())
            self._mostrar_canales(canales, 'Deportes en Vivo', select_pos=select_pos)

        elif tab_id == 102:  # Cine y Series
            todos = cargar_todos()
            canales = filtrar_por_categoria(todos, CATEGORIAS_CINE)
            canales.sort(key=lambda x: x.get('nombre', '').lower())
            self._mostrar_canales(canales, 'Cine y Series 24/7', select_pos=select_pos)

        elif tab_id == 103:  # Chile
            canales = cargar_canales('CL')
            canales.sort(key=lambda x: x.get('nombre', '').lower())
            self._mostrar_canales(canales, 'Chile', select_pos=select_pos)

        elif tab_id == 104:  # Infantil
            todos = cargar_todos()
            canales = filtrar_por_categoria(todos, CATEGORIAS_INFANTIL)
            canales.sort(key=lambda x: x.get('nombre', '').lower())
            self._mostrar_canales(canales, 'Infantil', select_pos=select_pos)

        elif tab_id == 105:  # Mundial (Internacional)
            self._mostrar_paises(select_pos=select_pos)

        elif tab_id == 106:  # Música
            todos = cargar_todos()
            canales = filtrar_por_categoria(todos, CATEGORIAS_MUSICA)
            canales.sort(key=lambda x: x.get('nombre', '').lower())
            self._mostrar_canales(canales, 'Música', select_pos=select_pos)

    # ── Mostrar grilla de canales ────────────────────────────────
    def _mostrar_canales(self, canales, titulo, select_pos=0):
        self.view_mode = self.MODE_GRID
        self.channels  = canales

        ctrl = self.getControl(8100)
        ctrl.reset()

        self.setProperty('total_count_label', f'{len(canales)} canales')
        self.setProperty('selected_name', titulo)
        self.setProperty('selected_extra', '')

        if not canales:
            xbmcgui.Dialog().notification(
                'Latarr TV PRO', 'Sin canales en esta sección',
                xbmcgui.NOTIFICATION_INFO, 2000)
            return

        fallback_img = os.path.join(
            ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'fallback_channel.png')

        items = []
        for ch in canales:
            nombre = ch.get('nombre', 'Canal')
            raw_logo = ch.get('logo', '')
            cat    = ch.get('categoria', '')
            pais   = ch.get('pais', '')

            logo = raw_logo if (raw_logo and raw_logo.startswith('http')) else fallback_img

            li = xbmcgui.ListItem(label=nombre)
            li.setArt({'thumb': logo, 'icon': logo, 'poster': logo})
            li.setProperty('stream_url', ch.get('url', ''))
            li.setProperty('alternativas', json.dumps(ch.get('alternativas', [])))
            li.setProperty('channel_name', nombre)
            li.setProperty('categoria', cat)
            pais_txt = NOMBRES_PAISES.get(pais, pais)
            li.setProperty('pais', pais_txt)
            li.setProperty('subtitle', f'{cat} · {pais_txt}')
            items.append(li)

        ctrl.addItems(items)
        self.setFocusId(8100)

        if 0 <= select_pos < len(items):
            try:
                ctrl.selectItem(select_pos)
            except Exception:
                pass

        self._update_info()

    # ── Mostrar agenda de eventos del día ───────────────────────
    def _mostrar_agenda(self, select_pos=0):
        self.view_mode   = self.MODE_AGENDA
        self.current_tab = 107

        self.setProperty('total_count_label', 'Cargando agenda...')
        self.setProperty('selected_name',  '⚽ Eventos del Día')
        self.setProperty('selected_extra', 'Conectando con la agenda deportiva...')

        eventos = cargar_agenda()
        self._agenda = eventos

        ctrl = self.getControl(8100)
        ctrl.reset()

        if not eventos:
            self.setProperty('total_count_label', '0 eventos')
            self.setProperty('selected_extra', 'Sin eventos disponibles hoy')
            xbmcgui.Dialog().notification(
                'Latarr TV PRO', 'No hay eventos hoy o sin conexión',
                xbmcgui.NOTIFICATION_INFO, 3000)
            return

        fallback_img = os.path.join(
            ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'fallback_channel.png')

        items = []
        for ev in eventos:
            attrs       = ev.get('attributes', {})
            titulo      = attrs.get('diary_description', 'Evento').strip().replace('\n', ' - ')
            hora_utc    = attrs.get('diary_hour', '00:00:00')
            hora        = _hora_local(hora_utc)
            embeds_data = attrs.get('embeds', {}).get('data', [])
            country_d   = attrs.get('country', {}).get('data', {})

            # Logo del torneo/país desde la API
            logo_url = ''
            if country_d:
                img_data = country_d.get('attributes', {}).get('image', {}).get('data', {})
                if img_data:
                    img_url = img_data.get('attributes', {}).get('url', '')
                    if img_url:
                        logo_url = IMG_BASE_URL + img_url if img_url.startswith('/') else img_url

            emoji     = _emoji_evento(titulo)
            n_senales = len(embeds_data)
            label_txt = f'{hora}  {titulo}'

            li = xbmcgui.ListItem(label=label_txt)
            li.setArt({'thumb': logo_url or fallback_img, 'icon': logo_url or fallback_img})
            li.setProperty('evento_titulo',  titulo)
            li.setProperty('evento_hora',    hora)
            li.setProperty('evento_emoji',   emoji)
            li.setProperty('evento_senales', json.dumps(embeds_data))
            li.setProperty('subtitle',       f'{hora} hrs  ·  {n_senales} señales disponibles')
            items.append(li)

        ctrl.addItems(items)
        self.setFocusId(8100)
        self.setProperty('total_count_label', f'{len(items)} eventos hoy')
        self.setProperty('selected_name',  '⚽ Eventos del Día')
        self.setProperty('selected_extra', 'Selecciona un partido para ver las señales')

        if 0 <= select_pos < len(items):
            try:
                ctrl.selectItem(select_pos)
            except Exception:
                pass

        self._update_info()

    # ── Reproducir evento desde la agenda ───────────────────────
    def _reproducir_evento(self, item, pos):
        titulo      = item.getProperty('evento_titulo')
        hora        = item.getProperty('evento_hora')
        emoji       = item.getProperty('evento_emoji')
        senales_raw = item.getProperty('evento_senales')

        senales = []
        try:
            senales = json.loads(senales_raw) if senales_raw else []
        except Exception:
            pass

        if not senales:
            xbmcgui.Dialog().notification(
                'Sin señales', f'No hay señales para: {titulo}',
                xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        # Armar lista de opciones para el diálogo
        opciones = []
        urls     = []
        for s in senales:
            sa           = s.get('attributes', {})
            nombre_senal = sa.get('embed_name', 'Señal')
            iframe       = sa.get('embed_iframe', '')
            url_real     = _decodificar_embed(iframe)
            if url_real:
                opciones.append(f'📺  {nombre_senal}')
                urls.append(url_real)

        if not opciones:
            xbmcgui.Dialog().notification(
                'Sin señales', 'No se pudo decodificar ninguna señal',
                xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        # Diálogo de selección de señal (estilo Apple TV)
        cabecera = f'{emoji}  {titulo}  •  {hora} hrs'
        eleccion = xbmcgui.Dialog().select(cabecera, opciones)

        if eleccion < 0:
            return  # Usuario canceló

        url_tvf90 = urls[eleccion]

        # Notificar que estamos resolviendo el stream
        xbmcgui.Dialog().notification(
            'Latarr TV PRO', 'Resolviendo señal, un momento...',
            xbmcgui.NOTIFICATION_INFO, 2000)

        # Resolver la URL real del .m3u8 desde TV90
        url_stream = _resolver_stream(url_tvf90)

        if not url_stream:
            xbmcgui.Dialog().notification(
                'Latarr TV PRO', 'No se pudo resolver la señal seleccionada',
                xbmcgui.NOTIFICATION_WARNING, 3000)
            return

        li = xbmcgui.ListItem(label=titulo)
        li.setInfo('video', {'title': titulo, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')

        player  = xbmc.Player()
        monitor = xbmc.Monitor()
        player.play(url_stream, li)

        started = False
        for _ in range(16):
            if monitor.abortRequested():
                return
            if player.isPlayingVideo() or player.isPlaying():
                started = True
                break
            monitor.waitForAbort(0.3)

        if started:
            self.played = True
            self.resume_data = {
                'tab':  107,
                'mode': self.MODE_AGENDA,
                'pos':  pos,
                'desde_int': False,
            }
            self.close()
        else:
            xbmcgui.Dialog().notification(
                'Latarr TV PRO', 'No se pudo conectar a la señal seleccionada',
                xbmcgui.NOTIFICATION_WARNING, 3000)

    # ── Mostrar grilla de países (Mundial) ──────────────────────
    def _mostrar_paises(self, select_pos=0):
        self.view_mode  = self.MODE_PAISES
        self.paises_list = cargar_paises()

        flags_dir = os.path.join(
            ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'flags')

        ctrl = self.getControl(8100)
        ctrl.reset()

        self.setProperty('total_count_label', f'{len(self.paises_list)} países')
        self.setProperty('selected_name', 'Mundial')
        self.setProperty('selected_extra', 'Selecciona un país')

        items = []
        for p in self.paises_list:
            codigo = p.get('codigo', '')
            nombre = NOMBRES_PAISES.get(codigo, p.get('nombre', codigo))
            total  = p.get('total', 0)

            flag = os.path.join(flags_dir, f'flag_{codigo}.png')
            thumb = flag if os.path.exists(flag) else ''

            li = xbmcgui.ListItem(label=nombre)
            li.setArt({'thumb': thumb, 'icon': thumb, 'poster': thumb})
            li.setProperty('country_code', codigo)
            li.setProperty('country_name', nombre)
            li.setProperty('subtitle', f'{total} canales')
            items.append(li)

        ctrl.addItems(items)
        self.setFocusId(8100)

        if 0 <= select_pos < len(items):
            try:
                ctrl.selectItem(select_pos)
            except Exception:
                pass

        self._update_info()

    # ── Actualizar info canal seleccionado ───────────────────────
    def _update_info(self):
        try:
            ctrl = self.getControl(8100)
            item = ctrl.getSelectedItem()
            if not item:
                return
            self.setProperty('selected_name', item.getLabel())
            self.setProperty('selected_extra',
                             item.getProperty('subtitle') or
                             item.getProperty('categoria') or '')
        except Exception:
            pass

    # ── Eventos ──────────────────────────────────────────────────
    def onAction(self, action):
        action_id = action.getId()

        if action_id in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            if self._desde_internacional:
                self._desde_internacional = False
                self._current_country_code = None
                self._current_country_name = None
                self._mostrar_paises()
                return
            elif self.view_mode == self.MODE_PAISES:
                self._cargar_tab(107)
                return
            else:
                self.played = False
                self.close()
                return

        try:
            super().onAction(action)
        except Exception:
            pass

        if self.getFocusId() == 8100:
            self._update_info()

    def onClick(self, control_id):
        if control_id in (101, 102, 103, 104, 105, 106, 107):
            self._cargar_tab(control_id)
            return

        if control_id == 8100:
            ctrl = self.getControl(8100)
            item = ctrl.getSelectedItem()
            pos  = ctrl.getSelectedPosition()
            if not item:
                return

            if self.view_mode == self.MODE_AGENDA:
                self._reproducir_evento(item, pos)
            elif self.view_mode == self.MODE_PAISES:
                codigo = item.getProperty('country_code')
                nombre = item.getProperty('country_name')
                canales = cargar_canales(codigo)
                canales.sort(key=lambda x: x.get('nombre', '').lower())
                self._desde_internacional = True
                self._current_country_code = codigo
                self._current_country_name = nombre
                self._mostrar_canales(canales, nombre)
            else:
                self._reproducir(item, pos)

    # ── Reproducción ─────────────────────────────────────────────
    def _reproducir(self, item, pos):
        url     = item.getProperty('stream_url')
        nombre  = item.getProperty('channel_name') or item.getLabel()
        logo    = item.getArt('thumb') or ''
        alts_raw = item.getProperty('alternativas')
        alternativas = []
        if alts_raw:
            try:
                alternativas = json.loads(alts_raw)
            except Exception:
                pass

        if not url:
            xbmcgui.Dialog().notification(
                'Latarr TV PRO', 'Enlace no disponible',
                xbmcgui.NOTIFICATION_WARNING, 2000)
            return

        li = xbmcgui.ListItem(label=nombre)
        li.setArt({'thumb': logo, 'icon': logo})
        li.setInfo('video', {'title': nombre, 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')

        player  = xbmc.Player()
        monitor = xbmc.Monitor()
        player.play(url, li)

        started = False
        for _ in range(14):
            if monitor.abortRequested():
                return
            if player.isPlayingVideo() or player.isPlaying():
                started = True
                break
            monitor.waitForAbort(0.3)

        if not started and alternativas:
            for alt_url in alternativas:
                if monitor.abortRequested():
                    return
                xbmcgui.Dialog().notification(
                    'Latarr TV PRO',
                    f'Probando alternativa para {nombre}...',
                    xbmcgui.NOTIFICATION_INFO, 1500)
                player.play(alt_url, li)
                for _ in range(12):
                    if monitor.abortRequested():
                        return
                    if player.isPlayingVideo() or player.isPlaying():
                        started = True
                        break
                    monitor.waitForAbort(0.3)
                if started:
                    break

        if started:
            self.played = True
            self.resume_data = {
                'tab': self.current_tab,
                'mode': self.view_mode,
                'pos': pos,
                'desde_int': self._desde_internacional,
                'country_code': self._current_country_code,
                'country_name': self._current_country_name,
            }
            self.close()
        else:
            xbmcgui.Dialog().notification(
                'Latarr TV PRO',
                f'No se pudo conectar a {nombre}',
                xbmcgui.NOTIFICATION_WARNING, 3000)


# ─────────────────────────────────────────────────────────────────
#  CICLO DE VIDA Y ENTRADA
# ─────────────────────────────────────────────────────────────────

def wait_for_playback(player, monitor):
    """Monitorea la reproducción del canal y regresa cuando se detiene."""
    while player.isPlaying():
        if monitor.abortRequested():
            return
        monitor.waitForAbort(0.3)


def launch_tv_pro():
    monitor = xbmc.Monitor()
    player = xbmc.Player()
    resume_data = None

    while not monitor.abortRequested():
        win = LatarrTVProWindow(
            'script-latarrtv-main.xml',
            ADDON_PATH,
            defaultSkin='Default',
            defaultRes='1080i',
            resume_data=resume_data
        )
        win.doModal()
        was_played = getattr(win, 'played', False)
        resume_data = getattr(win, 'resume_data', None)
        del win

        if was_played:
            wait_for_playback(player, monitor)
            continue
        else:
            xbmc.executebuiltin("ActivateWindow(home)")
            break


def instalar_keymap_netflix():
    """Garantiza que el boton Atras del control detenga el video de inmediato (estilo Netflix)."""
    try:
        import xbmcvfs
        translate = getattr(xbmcvfs, 'translatePath', getattr(xbmc, 'translatePath', None))
        if not translate:
            return
        km_dir = translate("special://userdata/keymaps/")
        if not xbmcvfs.exists(km_dir):
            xbmcvfs.mkdirs(km_dir)
        
        target = os.path.join(km_dir, "latarr_netflix_back.xml")
        xml_data = """<?xml version="1.0" encoding="UTF-8"?>
<keymap>
    <FullScreenVideo>
        <keyboard>
            <backspace>Stop</backspace>
            <escape>Stop</escape>
            <browser_back>Stop</browser_back>
            <key id="61448">Stop</key>
        </keyboard>
        <remote>
            <back>Stop</back>
            <exit>Stop</exit>
        </remote>
    </FullScreenVideo>
    <FullScreenLiveTV>
        <keyboard>
            <backspace>Stop</backspace>
            <escape>Stop</escape>
            <browser_back>Stop</browser_back>
            <key id="61448">Stop</key>
        </keyboard>
        <remote>
            <back>Stop</back>
            <exit>Stop</exit>
        </remote>
    </FullScreenLiveTV>
    <VideoOSD>
        <keyboard>
            <backspace>Stop</backspace>
            <escape>Stop</escape>
            <browser_back>Stop</browser_back>
            <key id="61448">Stop</key>
        </keyboard>
        <remote>
            <back>Stop</back>
            <exit>Stop</exit>
        </remote>
    </VideoOSD>
</keymap>"""
        debe_escribir = True
        if xbmcvfs.exists(target):
            try:
                f = xbmcvfs.File(target, 'r')
                actual = f.read()
                f.close()
                if actual.strip() == xml_data.strip():
                    debe_escribir = False
            except Exception:
                debe_escribir = True
        if debe_escribir:
            f = xbmcvfs.File(target, 'w')
            f.write(xml_data)
            f.close()
            xbmc.executebuiltin("Action(reloadkeymaps)")
            xbmc.log("[LATARR] Keymap Netflix instalado con exito", xbmc.LOGINFO)
    except Exception as e:
        xbmc.log(f"[LATARR] Error instalando keymap: {e}", xbmc.LOGWARNING)


if __name__ == '__main__':
    instalar_keymap_netflix()
    handle = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    if handle >= 0:
        xbmcplugin.endOfDirectory(handle, False)

    xbmc.executebuiltin("Dialog.Close(busydialog)")
    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    xbmc.executebuiltin("Dialog.Close(all, true)")

    if not check_disclaimer():
        xbmc.executebuiltin("ActivateWindow(home)")
        sys.exit(0)

    launch_tv_pro()
