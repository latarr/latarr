import os
import json
import urllib.parse
import xbmc
import xbmcgui
import xbmcaddon

try:
    from urllib.request import urlopen, Request
    from urllib.error import URLError
except ImportError:
    from urllib2 import urlopen, Request, URLError

addon = xbmcaddon.Addon()
POSTER_BASE = "https://image.tmdb.org/t/p/w500"
FANART_BASE = "https://image.tmdb.org/t/p/w1280"

# ── URL base del catalogo (Cloudflare Pages CDN) ──
GITHUB_RAW = addon.getSetting('github_url').rstrip('/')
if not GITHUB_RAW:
    GITHUB_RAW = "https://latarr-repo.pages.dev"

# ── Cache en memoria ──
_CACHE = {}

def clear_cache():
    global _CACHE
    _CACHE.clear()


def _fetch_json(url, timeout=15, use_cache=True):
    """Descarga un JSON desde Cloudflare Pages CDN y lo cachea en memoria."""
    if use_cache and url in _CACHE:
        return _CACHE[url]
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
            'Accept': 'application/json, text/plain, */*'
        }
        req = Request(url, headers=headers)
        resp = urlopen(req, timeout=timeout)
        data = json.loads(resp.read().decode('utf-8'))
        if use_cache and data is not None:
            _CACHE[url] = data
        return data
    except Exception as e:
        xbmc.log(f"[LATARR-GH] Error descargando {url}: {e}", xbmc.LOGERROR)
        return None


def _github(path):
    """Construye la URL completa de un archivo en el repo."""
    return f"{GITHUB_RAW}/{path}"


# ══════════════════════════════════════════════════
# CATALOGO COMPLETO (se descarga 1 vez y se filtra local)
# ══════════════════════════════════════════════════

def _load_catalog(media_type):
    """Carga el JSON completo de peliculas/series/anime."""
    filemap = {
        'movies': 'peliculas.json',
        'series': 'series.json',
        'anime': 'anime.json',
    }
    filename = filemap.get(media_type, 'peliculas.json')
    return _fetch_json(_github(filename)) or []


def _normalize(text):
    """Minusculas sin tildes para busqueda."""
    if not text:
        return ''
    import unicodedata
    nfkd = unicodedata.normalize('NFKD', text)
    return ''.join(c for c in nfkd if not unicodedata.combining(c)).lower().strip()


# ══════════════════════════════════════════════════
# PELICULAS
# ══════════════════════════════════════════════════

def get_top_movies(limit=25):
    data = _fetch_json(_github('top_movies.json'))
    return (data or [])[:limit]

def get_recent_movies(year=None, limit=25):
    catalog = _load_catalog('movies')
    if year:
        catalog = [m for m in catalog if str(m.get('year', '')) == str(year)]
    return catalog[:limit]

def get_movies_by_genre(genre, limit=25):
    catalog = _load_catalog('movies')
    norm_genre = _normalize(genre)
    filtered = [m for m in catalog if _normalize(m.get('genre', '')) == norm_genre]
    return filtered[:limit]

def get_movie_detail(tmdb_id):
    return _fetch_json(_github(f'links/movies/{tmdb_id}.json'))

def search_all(query, media_type='movies', limit=30):
    """Busca en el catalogo descargado filtrando por titulo."""
    catalog = _load_catalog(media_type)
    q = _normalize(query)
    results = [
        item for item in catalog
        if q in _normalize(item.get('clean_title', ''))
        or q in _normalize(item.get('title', ''))
    ]
    return {"total": len(results), "limit": limit, "offset": 0, "results": results[:limit]}

def get_catalog_years(media_type='movies'):
    filemap = {
        'movies': 'movies_years.json',
        'series': 'series_years.json',
        'anime': 'anime_years.json',
    }
    return _fetch_json(_github(filemap.get(media_type, 'movies_years.json'))) or []

def get_catalog_genres(media_type='movies', year=None):
    filemap = {
        'movies': 'movies_genres.json',
        'series': 'series_genres.json',
        'anime': 'anime_genres.json',
    }
    return _fetch_json(_github(filemap.get(media_type, 'movies_genres.json'))) or []

def get_catalog_items(media_type='movies', year=None, genre=None, offset=0, limit=40):
    """Carga catalogo completo y filtra/pagina localmente."""
    catalog = _load_catalog(media_type)

    if year and year != 'Todos':
        catalog = [i for i in catalog if str(i.get('year', '')) == str(year)]
    if genre and genre != 'Todos':
        norm_genre = _normalize(genre)
        catalog = [i for i in catalog if _normalize(i.get('genre', '')) == norm_genre]

    total = len(catalog)
    page = catalog[offset:offset + limit]
    return {"total": total, "limit": limit, "offset": offset, "results": page}


# ══════════════════════════════════════════════════
# SERIES
# ══════════════════════════════════════════════════

def get_top_series(limit=25):
    data = _fetch_json(_github('top_series.json'))
    return (data or [])[:limit]

def get_serie_detail(tmdb_id):
    return _fetch_json(_github(f'links/series/{tmdb_id}.json'))


# ══════════════════════════════════════════════════
# ANIME
# ══════════════════════════════════════════════════

def get_top_anime(limit=25):
    data = _fetch_json(_github('top_anime.json'))
    return (data or [])[:limit]

def get_anime_detail(tmdb_id, anime_type='series'):
    return _fetch_json(_github(f'links/anime/{tmdb_id}.json'))


# ══════════════════════════════════════════════════
# ACTORES
# ══════════════════════════════════════════════════

def get_actors(min_movies=5):
    data = _fetch_json(_github('actors.json'), use_cache=False) or []
    return [entry.get('actor', {}) for entry in data
            if len(entry.get('movies', [])) >= min_movies]

def get_actor_movies(actor_id):
    data = _fetch_json(_github('actors.json')) or []
    for entry in data:
        actor = entry.get('actor', {})
        aid = actor.get('id') or actor.get('actor_id')
        if aid == actor_id:
            movies = entry.get('movies', [])
            return {"total": len(movies), "results": movies}
    return {"total": 0, "results": []}
