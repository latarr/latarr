import sys
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import routing
import requests

plugin = routing.Plugin()
addon = xbmcaddon.Addon()

API_URL = addon.getSetting('api_url').rstrip('/')
POSTER_BASE = "https://image.tmdb.org/t/p/w342"
FANART_BASE = "https://image.tmdb.org/t/p/w1280"

# ---- Semaforo de salud del enlace (segun las semillas guardadas por el crawler) ----
# Verde: 100 o mas | Amarillo: 50 a 99 | Rojo: menos de 50.
# Es el dato del dia que se reviso la pagina: indica "probablemente sano", no lo garantiza.
def _semillas(valor):
    try:
        return int(valor or 0)
    except (TypeError, ValueError):
        return 0

def _numero(valor):
    """Primer numero de un valor. Acepta 3, '3' o '1 a 5' (packs de varias temporadas). Si no hay, 0."""
    if isinstance(valor, bool):
        return 0
    if isinstance(valor, (int, float)):
        return int(valor)
    m = re.search(r"\d+", str(valor or ""))
    return int(m.group()) if m else 0

def _ordenar(items, clave):
    """Ordena sin romper nunca el listado: si algun dato es raro, deja el orden original."""
    try:
        return sorted(items, key=clave)
    except Exception as e:
        xbmc.log(f"[LATARR] No se pudo ordenar: {str(e)}", xbmc.LOGERROR)
        return list(items)

def _color_salud(seeds):
    s = _semillas(seeds)
    if s >= 100:
        return 'FF2ECC71'   # verde
    if s >= 50:
        return 'FFF1C40F'   # amarillo
    return 'FFE74C3C'       # rojo

def _punto(seeds):
    return f"[COLOR {_color_salud(seeds)}]●[/COLOR]"

def _calidad(calidad, seeds):
    return f"[COLOR {_color_salud(seeds)}]{calidad}[/COLOR]"

def _clave_publica():
    """Clave incluida dentro del addon (resources/public_key.txt)."""
    try:
        import os
        ruta = os.path.join(addon.getAddonInfo('path'), 'resources', 'public_key.txt')
        with open(ruta, 'r') as f:
            return f.read().strip().upper()
    except Exception as e:
        xbmc.log(f"[LATARR] No se pudo leer la clave del addon: {str(e)}", xbmc.LOGERROR)
        return ''

def _clave_personal():
    """Clave opcional que el usuario puede poner en Ajustes (tiene prioridad)."""
    return (addon.getSetting('api_key') or '').strip().upper()

def _clave_activa():
    return _clave_personal() or _clave_publica()

def _validar_clave(clave):
    """True = valida, False = rechazada por el servidor, None = no se pudo comprobar."""
    try:
        r = requests.get(f"{API_URL}/auth/check", headers={'X-API-Key': clave}, timeout=10)
        if r.status_code == 200:
            return True
        if r.status_code in (401, 403):
            return False
        return None
    except Exception as e:
        xbmc.log(f"[LATARR] No se pudo validar la clave: {str(e)}", xbmc.LOGERROR)
        return None

def check_auth():
    dialog = xbmcgui.Dialog()
    personal = _clave_personal()
    clave = personal or _clave_publica()
    ok = _validar_clave(clave) if clave else False
    if ok is True:
        return True
    if ok is None:
        dialog.notification('Latarr', 'No se pudo conectar con el servidor', xbmcgui.NOTIFICATION_ERROR, 5000)
        return False
    if personal:
        # La clave personal ya no sirve: se descarta y se intenta con la del addon
        addon.setSetting('api_key', '')
        dialog.notification('Latarr', 'Tu clave personal ya no es valida', xbmcgui.NOTIFICATION_ERROR, 4000)
        if _validar_clave(_clave_publica()) is True:
            return True
    dialog.ok('Latarr', 'El acceso de este addon fue renovado.[CR]Actualiza Latarr desde el repositorio y vuelve a entrar.')
    return False

def get_api_data(endpoint, params=None):
    try:
        url = f"{API_URL}{endpoint}"
        response = requests.get(url, params=params, headers={'X-API-Key': _clave_activa()}, timeout=10)
        if response.status_code in (401, 403):
            if _clave_personal():
                addon.setSetting('api_key', '')
            xbmcgui.Dialog().notification('Latarr', 'Acceso invalido. Actualiza el addon.', xbmcgui.NOTIFICATION_ERROR)
            return None
        if response.status_code == 429:
            xbmcgui.Dialog().notification('Latarr', 'Muchas solicitudes. Espera un momento.', xbmcgui.NOTIFICATION_ERROR)
            return None
        if response.status_code == 503:
            xbmcgui.Dialog().notification('Latarr', 'Servidor ocupado. Intenta de nuevo en unos segundos.', xbmcgui.NOTIFICATION_ERROR)
            return None
        response.raise_for_status()
        return response.json()
    except Exception as e:
        xbmc.log(f"[LATARR] Error API: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Latarr', 'Error de conexión', xbmcgui.NOTIFICATION_ERROR)
        return None

def build_listitem(title, poster_path, overview, year, genre, rating):
    li = xbmcgui.ListItem(title)
    info = {
        'title': title,
        'plot': overview or 'Sin sinopsis disponible.',
        'year': int(year) if year and str(year).isdigit() else 0,
        'genre': genre,
        'rating': float(rating) if rating else 0.0
    }
    li.setInfo('video', info)
    
    art = {}
    if poster_path:
        art['poster'] = f"{POSTER_BASE}{poster_path}"
        art['thumb'] = f"{POSTER_BASE}{poster_path}"
        art['fanart'] = f"{FANART_BASE}{poster_path}"
    li.setArt(art)
    return li

# ==========================================
# MENÚ PRINCIPAL
# ==========================================
@plugin.route('/')
def index():
    if not check_auth(): return
    
    ui_mode = addon.getSetting('ui_mode')
    if ui_mode == "1":
        # Modo Clásico de Directorios Kodi
        add_dir("🌟 Entrar a Modo Cinema (Apple TV)", plugin.url_for(launch_cinema))
        add_dir("🏆 Lo Mejor de LATARR", plugin.url_for(top_menu))
        add_dir("🎬 Películas", plugin.url_for(movie_years))
        add_dir("📺 Series de TV", plugin.url_for(serie_years))
        add_dir("🍿 Anime", plugin.url_for(anime_years))
        add_dir("🔍 Búsqueda Global", plugin.url_for(search_input))
        xbmcplugin.endOfDirectory(plugin.handle)
        return

    # Modo Apple TV Cinema Predeterminado:
    # 1. Cierra el ciclo de directorio de Kodi inmediatamente
    xbmcplugin.endOfDirectory(plugin.handle, False)
    # 2. Cierra cualquier diálogo de carga activo (rueda azul)
    xbmc.executebuiltin("Dialog.Close(busydialog)")
    xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
    xbmc.executebuiltin("Dialog.Close(all, true)")
    # 3. Abre la interfaz
    launch_cinema()
    xbmc.executebuiltin("ActivateWindow(home)")

def _detectar_episodio_en_curso(player):
    """
    En un pack, el capítulo lo elige Elementum DESPUÉS de que el addon lanza la reproducción,
    así que el historial quedaba con el nombre del pack. Aquí leemos el nombre del archivo que
    realmente está sonando, sacamos temporada/episodio y corregimos la sesión actual.
    Devuelve True cuando ya no hace falta seguir intentando.
    """
    from resources.lib import history
    cur = history.get_current_playback()
    if not cur:
        return True
    if cur.get('media_type') not in ('series', 'anime'):
        return True
    # Si el ítem ya trae episodio (fuente de un solo capítulo), no se toca
    if str(cur.get('episode') or '').strip() not in ('', '0'):
        return True

    candidatos = []
    try:
        candidatos.append(player.getPlayingFile())
    except Exception:
        pass
    for lbl in ('Player.Filename', 'Player.Filenameandpath'):
        try:
            candidatos.append(xbmc.getInfoLabel(lbl))
        except Exception:
            pass

    for raw in candidatos:
        # plugin:// lleva el magnet (nombre del pack), no el archivo; se ignora
        if not raw or str(raw).startswith('plugin://'):
            continue
        nombre = urllib.parse.unquote(str(raw)).split('?')[0]
        sn, ep = history.parse_episode(nombre)
        if not ep:
            continue
        season_final = sn or _numero(cur.get('season')) or 0
        label = history.episode_label(season_final, ep)
        cur['season'] = str(season_final) if season_final else ''
        cur['episode'] = str(ep)
        cur['file_name'] = nombre.replace('\\', '/').split('/')[-1]
        cur['display_title'] = f"{cur.get('title') or 'Serie'} - Episodio {label}"
        xbmc.log(f"[LATARR] Episodio detectado dentro del pack: {label} <- {cur['file_name']}", xbmc.LOGINFO)
        return True
    return False

def wait_for_playback(player, monitor):
    """Monitorea la reproducción en curso y guarda el progreso en el historial local al terminar."""
    last_time = 0.0
    total_time = 0.0
    fullscreen_active = False

    # Segundo al que hay que reanudar (lo deja home.py en el ítem de la sesión)
    try:
        from resources.lib import history as _h
        _cur = _h.get_current_playback() or {}
        seek_to = float(_cur.get('seek_to') or 0)
    except Exception:
        seek_to = 0.0
    ep_detected = False   # ¿ya sabemos qué capítulo del pack se está viendo?
    ep_tries = 0
    seek_done = seek_to <= 0
    seek_tries = 0
    seek_first_seen = None   # cuándo apareció por primera vez la duración
    seek_last_try = 0.0

    while player.isPlaying():
        if monitor.abortRequested():
            return
        try:
            if player.isPlayingVideo():
                # Forzar pantalla completa inmediata apenas haya video
                if not fullscreen_active:
                    xbmc.executebuiltin("ActivateWindow(fullscreenvideo)")
                    fullscreen_active = True
                t = player.getTime()
                tot = player.getTotalTime()
                if tot > 0:
                    # Packs: descubrir qué capítulo está sonando (se reintenta ~18 s)
                    if not ep_detected and ep_tries < 60:
                        ep_tries += 1
                        ep_detected = _detectar_episodio_en_curso(player)
                        if not ep_detected and ep_tries == 60:
                            xbmc.log("[LATARR] No se pudo detectar el episodio del pack (nombre de archivo sin patrón reconocible)", xbmc.LOGWARNING)
                    # Reanudar: saltar UNA vez, cuando Kodi ya conoce la duración
                    if not seek_done:
                        import time as _time
                        now = _time.time()
                        if seek_first_seen is None:
                            seek_first_seen = now
                        if t >= seek_to - 5:
                            # Ya estamos en el punto correcto: listo
                            xbmc.log(f"[LATARR] Reanudación OK en {t:.0f}s (objetivo {seek_to:.0f}s)", xbmc.LOGINFO)
                            seek_done = True
                        elif seek_to >= tot - 10:
                            seek_done = True
                        elif seek_tries >= 8:
                            xbmc.log("[LATARR] No se pudo reanudar tras 8 intentos", xbmc.LOGWARNING)
                            seek_done = True
                        elif now - seek_first_seen >= 1.5 and now - seek_last_try >= 4.0:
                            # Elementum puede ignorar el seek mientras arma el stream:
                            # reintentamos cada 4 s hasta que el tiempo realmente cambie
                            seek_tries += 1
                            seek_last_try = now
                            xbmc.log(f"[LATARR] seekTime({seek_to:.0f}) intento {seek_tries} (t actual {t:.0f}s)", xbmc.LOGINFO)
                            player.seekTime(seek_to)
                    last_time = t
                    total_time = tot
        except Exception:
            pass
        monitor.waitForAbort(0.3)

    # Al finalizar el video (Stop o fin natural):
    try:
        from resources.lib import history
        cur_item = history.get_current_playback()
        if cur_item and total_time > 0:
            history.save_progress(
                item_data=cur_item,
                current_time=last_time,
                total_time=total_time,
                file_name=cur_item.get('file_name'),
                file_index=cur_item.get('file_index')
            )
            history.clear_current_playback()
    except Exception as e:
        xbmc.log(f"[LATARR] Error guardando progreso de video: {str(e)}", xbmc.LOGERROR)

    xbmc.executebuiltin("Dialog.Close(all, true)")

@plugin.route('/cinema')
def launch_cinema():
    try:
        from resources.lib.windows.home import LatarrHomeWindow
        from resources.lib.windows.catalog import LatarrCatalogDialog
        from resources.lib.windows.sources import LatarrSourcesDialog
        from resources.lib.windows.search import LatarrSearchDialog
        monitor = xbmc.Monitor()
        player = xbmc.Player()

        resume_data = None

        while not monitor.abortRequested():
            # CASO 1: Para Series y Anime, reanudar DIRECTAMENTE en Fuentes (lista de capítulos)
            if resume_data and resume_data.get('section') == 'sources':
                s_data = resume_data
                resume_data = None

                dlg = LatarrSourcesDialog(
                    'script-latarr-sources.xml',
                    addon.getAddonInfo('path'),
                    defaultSkin='Default',
                    defaultRes='1080i',
                    tmdb_id=s_data.get('tmdb_id'),
                    media_type=s_data.get('media_type'),
                    title=s_data.get('title'),
                    poster=s_data.get('poster'),
                    fanart=s_data.get('fanart'),
                    plot=s_data.get('plot'),
                    year=s_data.get('year'),
                    rating=s_data.get('rating'),
                    genre=s_data.get('genre')
                )
                dlg.doModal()
                was_played = getattr(dlg, 'played', False)
                del dlg

                if was_played:
                    # El usuario reprodujo otro capítulo: conservamos la serie para volver a Fuentes al terminar
                    resume_data = s_data
                    wait_for_playback(player, monitor)
                    continue
                else:
                    # El usuario dio Atrás en Fuentes: volvemos al padre (Catálogo o Inicio)
                    parent = s_data.get('parent')
                    if parent:
                        resume_data = parent
                    continue

            # CASO 2: Si el usuario estaba viendo una película desde el Catálogo:
            elif resume_data and resume_data.get('section') == 'catalog':
                r_type = resume_data.get('media_type', 'movies')
                r_off = resume_data.get('offset', 0)
                r_yr = resume_data.get('year', 'Todos')
                r_gn = resume_data.get('genre', 'Todos')
                r_pos = resume_data.get('pos', 0)
                resume_data = None

                dlg = LatarrCatalogDialog(
                    'script-latarr-catalog.xml',
                    addon.getAddonInfo('path'),
                    defaultSkin='Default',
                    defaultRes='1080i',
                    media_type=r_type,
                    addon_path=addon.getAddonInfo('path'),
                    initial_offset=r_off,
                    initial_year=r_yr,
                    initial_genre=r_gn,
                    initial_pos=r_pos
                )
                dlg.doModal()
                was_played = getattr(dlg, 'played', False)
                if was_played:
                    resume_data = getattr(dlg, 'resume_data', None)
                del dlg

                if was_played:
                    wait_for_playback(player, monitor)
                    continue
                else:
                    # El usuario dio Atrás en el catálogo: volvemos al Home (Inicio)
                    continue

            # CASO 3: Si el usuario estaba en Búsqueda:
            elif resume_data and resume_data.get('section') == 'search':
                s_query = resume_data.get('query', '')
                s_items = resume_data.get('items', [])
                s_pos = resume_data.get('pos', 0)
                resume_data = None

                dlg = LatarrSearchDialog(
                    'script-latarr-search.xml',
                    addon.getAddonInfo('path'),
                    defaultSkin='Default',
                    defaultRes='1080i',
                    query=s_query,
                    items=s_items,
                    addon_path=addon.getAddonInfo('path'),
                    initial_pos=s_pos
                )
                dlg.doModal()
                was_played = getattr(dlg, 'played', False)
                if was_played:
                    resume_data = getattr(dlg, 'resume_data', None)
                del dlg

                if was_played:
                    wait_for_playback(player, monitor)
                    continue
                else:
                    # El usuario dio Atrás en los resultados de búsqueda: volvemos al Home
                    continue

            # CASO 3b: Si el usuario estaba en el Historial: se reabre (recargado, con el progreso nuevo)
            elif resume_data and resume_data.get('section') == 'history':
                from resources.lib.windows.history_win import LatarrHistoryDialog
                h_pos = resume_data.get('pos', 0)
                resume_data = None

                dlg = LatarrHistoryDialog(
                    'script-latarr-history.xml',
                    addon.getAddonInfo('path'),
                    defaultSkin='Default',
                    defaultRes='1080i',
                    addon_path=addon.getAddonInfo('path'),
                    initial_pos=h_pos
                )
                dlg.doModal()
                was_played = getattr(dlg, 'played', False)
                if was_played:
                    resume_data = getattr(dlg, 'resume_data', None)
                del dlg

                if was_played:
                    wait_for_playback(player, monitor)
                    continue
                else:
                    # Atrás en el Historial: volvemos al Home
                    continue

            # CASO 4: Modo normal / Reanudar en Home (Inicio con foco exacto en el carrusel)
            h_container = 5001
            h_pos = 0
            if resume_data and resume_data.get('section') == 'home':
                h_container = resume_data.get('container', 5001)
                h_pos = resume_data.get('pos', 0)
                resume_data = None

            win = LatarrHomeWindow(
                'script-latarr-main.xml',
                addon.getAddonInfo('path'),
                defaultSkin='Default',
                defaultRes='1080i',
                initial_container=h_container,
                initial_pos=h_pos
            )
            win.doModal()
            was_played = getattr(win, 'played', False)
            if was_played:
                resume_data = getattr(win, 'resume_data', None)
            del win

            if was_played:
                # La ventana se cerró porque comenzó la reproducción:
                wait_for_playback(player, monitor)
            else:
                # El usuario pulsó Atrás para salir del addon
                xbmc.executebuiltin("ActivateWindow(home)")
                break
    except Exception as e:
        xbmc.log(f"[LATARR] Error en ciclo Cinema: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Latarr', f'Error UI Cinema: {str(e)}', xbmcgui.NOTIFICATION_ERROR)
    finally:
        xbmc.executebuiltin("Dialog.Close(busydialog)")
        xbmc.executebuiltin("Dialog.Close(busydialognocancel)")
        xbmc.executebuiltin("ActivateWindow(home)")

# ==========================================
# LO MEJOR DE LATARR (TOP)
# ==========================================
@plugin.route('/top')
def top_menu():
    add_dir("🎬 Top Películas", plugin.url_for(top_catalog, media_type="movies"))
    add_dir("📺 Top Series", plugin.url_for(top_catalog, media_type="series"))
    add_dir("🍿 Top Anime", plugin.url_for(top_catalog, media_type="anime"))
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/top/catalog/<media_type>')
def top_catalog(media_type):
    data = get_api_data(f'/{media_type}/top', params={'limit': 50})
    if data:
        for m in data:
            li = build_listitem(m.get('title'), m.get('poster_path'), m.get('overview', ''), m.get('year', ''), m.get('genre', ''), m.get('rating', 0))
            if media_type == 'movies':
                url = plugin.url_for(movie_links, tmdb_id=m.get('tmdb_id'))
            elif media_type == 'series':
                url = plugin.url_for(serie_links, tmdb_id=m.get('tmdb_id'))
            else:
                url = plugin.url_for(anime_serie_links, tmdb_id=m.get('tmdb_id'))
            xbmcplugin.addDirectoryItem(plugin.handle, url, li, isFolder=True)
            
    xbmcplugin.setContent(plugin.handle, 'movies' if media_type == 'movies' else 'tvshows')
    xbmcplugin.endOfDirectory(plugin.handle)

# ==========================================
# SECCIÓN PELÍCULAS
# ==========================================
@plugin.route('/movies/years')
def movie_years():
    add_dir("🌟 Todos los años", plugin.url_for(movie_genres, year="todos"))
    data = get_api_data('/movies/years')
    if data:
        for row in data:
            add_dir(f"📅 Año {row.get('year')}", plugin.url_for(movie_genres, year=row.get('year')))
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/movies/genres/<year>')
def movie_genres(year):
    add_dir("🌟 Todos los géneros", plugin.url_for(movie_catalog, year=year, genre="todos", offset=0))
    data = get_api_data('/movies/genres', params={'year': year})
    if data:
        for row in data:
            add_dir(f"🎭 {row.get('genre')}", plugin.url_for(movie_catalog, year=year, genre=row.get('genre'), offset=0))
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/movies/catalog/<year>/<genre>/<offset>')
def movie_catalog(year, genre, offset):
    limit = 60
    data = get_api_data('/movies', params={'year': year, 'genre': genre, 'offset': offset, 'limit': limit})
    if data and 'results' in data:
        for m in data['results']:
            li = build_listitem(m.get('clean_title'), m.get('poster_path'), m.get('overview'), m.get('year'), m.get('genre'), m.get('rating'))
            url = plugin.url_for(movie_links, tmdb_id=m.get('tmdb_id'))
            xbmcplugin.addDirectoryItem(plugin.handle, url, li, isFolder=True)
            
        if int(offset) + limit < data.get('total', 0):
            add_dir(">> Siguiente Página", plugin.url_for(movie_catalog, year=year, genre=genre, offset=int(offset)+limit))
            
    xbmcplugin.setContent(plugin.handle, 'movies')
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/movies/links/<tmdb_id>')
def movie_links(tmdb_id):
    data = get_api_data(f'/movies/{tmdb_id}')
    if data and 'links' in data:
        for link in _ordenar(data['links'], lambda l: -_semillas(l.get('seeds'))):
            title = f"{_punto(link.get('seeds'))} {_calidad(link.get('quality', 'SD'), link.get('seeds'))} | Subs Español | {link.get('size', '0GB')} | {link.get('source')}"
            li = xbmcgui.ListItem(title)
            li.setInfo('video', {'title': title, 'plot': data['metadata'].get('clean_title', '')})
            li.setProperty('IsPlayable', 'true')
            url = plugin.url_for(play_magnet, magnet=urllib.parse.quote_plus(link.get('magnet', '')))
            xbmcplugin.addDirectoryItem(plugin.handle, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)


# ==========================================
# RUTAS SERIES DE TV
# ==========================================
@plugin.route('/series/years')
def serie_years(): render_tv_years('series')
@plugin.route('/series/genres/<year>')
def serie_genres(year): render_tv_genres('series', year)
@plugin.route('/series/catalog/<year>/<genre>/<offset>')
def serie_catalog(year, genre, offset): render_tv_catalog('series', year, genre, offset)
@plugin.route('/series/links/<tmdb_id>')
def serie_links(tmdb_id): render_tv_links('series', tmdb_id)

# ==========================================
# SECCIÓN ANIME — Sub-menú
# ==========================================
@plugin.route('/anime/years')
def anime_years():
    """Sub-menú principal de Anime: Series o Películas."""
    add_dir("📺 Series", plugin.url_for(anime_serie_years))
    add_dir("🎬 Películas", plugin.url_for(anime_movie_years))
    xbmcplugin.endOfDirectory(plugin.handle)

# — Anime Series —
@plugin.route('/anime/series/years')
def anime_serie_years(): render_tv_years('anime', anime_type='series')
@plugin.route('/anime/series/genres/<year>')
def anime_serie_genres(year): render_tv_genres('anime', year, anime_type='series')
@plugin.route('/anime/series/catalog/<year>/<genre>/<offset>')
def anime_serie_catalog(year, genre, offset): render_tv_catalog('anime', year, genre, offset, anime_type='series')
@plugin.route('/anime/series/links/<tmdb_id>')
def anime_serie_links(tmdb_id): render_tv_links('anime', tmdb_id, anime_type='series')

# — Anime Películas —
@plugin.route('/anime/movies/years')
def anime_movie_years(): render_anime_movie_years()
@plugin.route('/anime/movies/genres/<year>')
def anime_movie_genres(year): render_anime_movie_genres(year)
@plugin.route('/anime/movies/catalog/<year>/<genre>/<offset>')
def anime_movie_catalog(year, genre, offset): render_anime_movie_catalog(year, genre, offset)
@plugin.route('/anime/movies/links/<tmdb_id>')
def anime_movie_links(tmdb_id): render_anime_movie_links(tmdb_id)

# ==========================================
# LÓGICA COMPARTIDA DE SERIES Y ANIME-SERIES
# ==========================================
def get_tv_route(media_type, view_type):
    """Devuelve la ruta exacta para evitar el error de Kodi routing"""
    if media_type == 'series':
        if view_type == 'genres': return serie_genres
        if view_type == 'catalog': return serie_catalog
        if view_type == 'links': return serie_links
    else:  # anime series
        if view_type == 'genres': return anime_serie_genres
        if view_type == 'catalog': return anime_serie_catalog
        if view_type == 'links': return anime_serie_links

def render_tv_years(media_type, anime_type=None):
    r_genres = get_tv_route(media_type, 'genres')
    add_dir("🌟 Todos los años", plugin.url_for(r_genres, year="todos"))
    params = {'type': anime_type} if anime_type else {}
    data = get_api_data(f'/{media_type}/years', params=params)
    if data:
        for row in data:
            add_dir(f"📅 Año {row.get('year')}", plugin.url_for(r_genres, year=row.get('year')))
    xbmcplugin.endOfDirectory(plugin.handle)

def render_tv_genres(media_type, year, anime_type=None):
    r_catalog = get_tv_route(media_type, 'catalog')
    add_dir("🌟 Todos los géneros", plugin.url_for(r_catalog, year=year, genre="todos", offset=0))
    params = {'year': year}
    if anime_type:
        params['type'] = anime_type
    data = get_api_data(f'/{media_type}/genres', params=params)
    if data:
        for row in data:
            add_dir(f"🎭 {row.get('genre')}", plugin.url_for(r_catalog, year=year, genre=row.get('genre'), offset=0))
    xbmcplugin.endOfDirectory(plugin.handle)

def render_tv_catalog(media_type, year, genre, offset, anime_type=None):
    limit = 60
    r_catalog = get_tv_route(media_type, 'catalog')
    r_links = get_tv_route(media_type, 'links')
    params = {'year': year, 'genre': genre, 'offset': offset, 'limit': limit}
    if anime_type:
        params['type'] = anime_type
    data = get_api_data(f'/{media_type}', params=params)
    if data and 'results' in data:
        for s in data['results']:
            li = build_listitem(s.get('clean_title'), s.get('poster_path'), s.get('overview'), s.get('year'), s.get('genre'), s.get('rating'))
            url = plugin.url_for(r_links, tmdb_id=s.get('tmdb_id'))
            xbmcplugin.addDirectoryItem(plugin.handle, url, li, isFolder=True)
        if int(offset) + limit < data.get('total', 0):
            add_dir(">> Siguiente Página", plugin.url_for(r_catalog, year=year, genre=genre, offset=int(offset)+limit))
    xbmcplugin.setContent(plugin.handle, 'tvshows')
    xbmcplugin.endOfDirectory(plugin.handle)

def render_tv_links(media_type, tmdb_id, anime_type=None):
    params = {'type': anime_type} if anime_type else {}
    data = get_api_data(f'/{media_type}/{tmdb_id}', params=params)
    if not data: return
    for pack in _ordenar(data.get('packs', []), lambda p: (_numero(p.get('season')), -_semillas(p.get('seeds')))):
        sn = pack.get('season') or 0
        t = "PACK COMPLETO" if sn == 0 else f"Temporada {sn} - Completa"
        title = f"{_punto(pack.get('seeds'))} [PACK] {t} | {_calidad(pack.get('quality'), pack.get('seeds'))} | Subs Español | {pack.get('size')} | {pack.get('source')}"
        li = xbmcgui.ListItem(title)
        li.setProperty('IsPlayable', 'true')
        url = plugin.url_for(play_magnet, magnet=urllib.parse.quote_plus(pack.get('magnet', '')))
        xbmcplugin.addDirectoryItem(plugin.handle, url, li, isFolder=False)
    for ep in _ordenar(data.get('episodes', []), lambda e: (_numero(e.get('season')), _numero(e.get('episode')), -_semillas(e.get('seeds')))):
        title = f"{_punto(ep.get('seeds'))} S{str(ep.get('season', 0)).zfill(2)}E{str(ep.get('episode', 0)).zfill(2)} | {_calidad(ep.get('quality'), ep.get('seeds'))} | Subs Español | {ep.get('size')} | {ep.get('source')}"
        li = xbmcgui.ListItem(title)
        li.setProperty('IsPlayable', 'true')
        url = plugin.url_for(play_magnet, magnet=urllib.parse.quote_plus(ep.get('magnet', '')))
        xbmcplugin.addDirectoryItem(plugin.handle, url, li, isFolder=False)
    xbmcplugin.setContent(plugin.handle, 'episodes')
    xbmcplugin.endOfDirectory(plugin.handle)

# ==========================================
# LÓGICA PELÍCULAS ANIME
# ==========================================
def render_anime_movie_years():
    add_dir("🌟 Todos los años", plugin.url_for(anime_movie_genres, year="todos"))
    data = get_api_data('/anime/years', params={'type': 'movie'})
    if data:
        for row in data:
            add_dir(f"📅 Año {row.get('year')}", plugin.url_for(anime_movie_genres, year=row.get('year')))
    xbmcplugin.endOfDirectory(plugin.handle)

def render_anime_movie_genres(year):
    add_dir("🌟 Todos los géneros", plugin.url_for(anime_movie_catalog, year=year, genre="todos", offset=0))
    data = get_api_data('/anime/genres', params={'year': year, 'type': 'movie'})
    if data:
        for row in data:
            add_dir(f"🎭 {row.get('genre')}", plugin.url_for(anime_movie_catalog, year=year, genre=row.get('genre'), offset=0))
    xbmcplugin.endOfDirectory(plugin.handle)

def render_anime_movie_catalog(year, genre, offset):
    limit = 60
    data = get_api_data('/anime', params={'year': year, 'genre': genre, 'offset': offset, 'limit': limit, 'type': 'movie'})
    if data and 'results' in data:
        for m in data['results']:
            li = build_listitem(m.get('clean_title'), m.get('poster_path'), m.get('overview'), m.get('year'), m.get('genre'), m.get('rating'))
            url = plugin.url_for(anime_movie_links, tmdb_id=m.get('tmdb_id'))
            xbmcplugin.addDirectoryItem(plugin.handle, url, li, isFolder=True)
        if int(offset) + limit < data.get('total', 0):
            add_dir(">> Siguiente Página", plugin.url_for(anime_movie_catalog, year=year, genre=genre, offset=int(offset)+limit))
    xbmcplugin.setContent(plugin.handle, 'movies')
    xbmcplugin.endOfDirectory(plugin.handle)

def render_anime_movie_links(tmdb_id):
    data = get_api_data(f'/anime/{tmdb_id}', params={'type': 'movie'})
    if data and 'links' in data:
        for link in _ordenar(data['links'], lambda l: -_semillas(l.get('seeds'))):
            title = f"{_punto(link.get('seeds'))} {_calidad(link.get('quality', 'SD'), link.get('seeds'))} | Subs Español | {link.get('size', '0GB')} | {link.get('source')}"
            li = xbmcgui.ListItem(title)
            li.setInfo('video', {'title': title, 'plot': data['metadata'].get('clean_title', '')})
            li.setProperty('IsPlayable', 'true')
            url = plugin.url_for(play_magnet, magnet=urllib.parse.quote_plus(link.get('magnet', '')))
            xbmcplugin.addDirectoryItem(plugin.handle, url, li, isFolder=False)
    xbmcplugin.endOfDirectory(plugin.handle)


# ==========================================
# BÚSQUEDA Y REPRODUCCIÓN
# ==========================================
@plugin.route('/search')
def search_input():
    dialog = xbmcgui.Dialog()
    query = dialog.input('¿Qué estás buscando?', type=xbmcgui.INPUT_ALPHANUM)
    if query:
        add_dir(f"🎬 Películas: '{query}'", plugin.url_for(search_results, media_type='movies', query=urllib.parse.quote_plus(query), offset=0))
        add_dir(f"📺 Series: '{query}'", plugin.url_for(search_results, media_type='series', query=urllib.parse.quote_plus(query), offset=0))
        add_dir(f"⛩️ Anime: '{query}'", plugin.url_for(search_results, media_type='anime', query=urllib.parse.quote_plus(query), offset=0))
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/search/results/<media_type>/<query>/<offset>')
def search_results(media_type, query, offset):
    q = urllib.parse.unquote_plus(query)
    limit = 60
    data = get_api_data(f'/{media_type}', params={'search': q, 'offset': offset, 'limit': limit})
    
    if data and 'results' in data:
        for r in data['results']:
            li = build_listitem(r.get('clean_title'), r.get('poster_path'), r.get('overview'), r.get('year'), r.get('genre'), r.get('rating'))
            if media_type == 'movies':
                url = plugin.url_for(movie_links, tmdb_id=r.get('tmdb_id'))
            else:
                r_links = get_tv_route(media_type, 'links')
                url = plugin.url_for(r_links, tmdb_id=r.get('tmdb_id'))
            xbmcplugin.addDirectoryItem(plugin.handle, url, li, isFolder=True)
            
        if int(offset) + limit < data.get('total', 0):
            add_dir(">> Siguiente Página", plugin.url_for(search_results, media_type=media_type, query=query, offset=int(offset)+limit))
            
    xbmcplugin.setContent(plugin.handle, 'movies' if media_type == 'movies' else 'tvshows')
    xbmcplugin.endOfDirectory(plugin.handle)

@plugin.route('/play/<magnet>')
def play_magnet(magnet):
    mag = urllib.parse.unquote_plus(magnet)
    engine = addon.getSetting('torrent_engine')
    
    if engine == "1": # Torrest
        play_url = f"plugin://plugin.video.torrest/play_magnet?magnet={urllib.parse.quote_plus(mag)}"
    else: # Elementum (Predeterminado)
        play_url = f"plugin://plugin.video.elementum/play?uri={urllib.parse.quote_plus(mag)}"
        
    li = xbmcgui.ListItem(path=play_url)
    xbmcplugin.setResolvedUrl(plugin.handle, True, li)

def add_dir(name, url):
    li = xbmcgui.ListItem(name)
    xbmcplugin.addDirectoryItem(handle=plugin.handle, url=url, listitem=li, isFolder=True)

if __name__ == '__main__':
    plugin.run()
